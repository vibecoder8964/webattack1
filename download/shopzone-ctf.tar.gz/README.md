# ShopZone CTF Challenge

A shopping website with 6 chained vulnerabilities leading to root access and a flag.

## Quick Deploy to Render.com (Free Tier)

### Option A: GitHub + Render Dashboard (Recommended)

1. **Create a GitHub repository:**
   - Go to https://github.com/new
   - Name it `shopzone-ctf`
   - Make it **Private** (to hide the solution)
   - Don't initialize with README

2. **Push the code:**
   ```bash
   cd shopzone-ctf
   git remote add origin https://github.com/YOUR_USERNAME/shopzone-ctf.git
   git push -u origin main
   ```

3. **Deploy on Render:**
   - Go to https://dashboard.render.com
   - Click **New** → **Web Service**
   - Connect your GitHub repo
   - Render auto-detects the Dockerfile
   - Select **Free** plan
   - Click **Create Web Service**
   - Wait ~2-3 minutes for build and deploy

4. **Your site will be live at:** `https://shopzone-ctf.onrender.com`

### Option B: Render Blueprint (render.yaml)

1. Push code to GitHub (same as above)
2. Go to https://dashboard.render.com
3. Click **New** → **Blueprint**
4. Connect your GitHub repo
5. Render reads `render.yaml` and creates the service automatically

## Environment Details

- **Runtime:** Docker (Node.js 20 Alpine)
- **Port:** Auto-detected via `PORT` env variable
- **Dependencies:** Only Express.js
- **Build size:** ~23KB source, ~50MB Docker image

## Burp Suite Compatibility

The app uses standard HTTP/HTTPS - fully compatible with Burp Suite proxy. Configure your browser to proxy through `127.0.0.1:8080` and all requests/responses will be interceptable.

## Vulnerability Chain (6 Steps)

1. **Username Enumeration** - Login reveals whether username exists
2. **SQL Injection** - Login bypass via SQLi
3. **IDOR** - Access other users' profiles
4. **Path Traversal** - Read server files
5. **SSRF** - Access internal admin service
6. **Command Injection** - RCE via diagnostic tool

## Hints Discovery Path

- Chat support conversations leak vulnerability hints
- User profiles reveal blog URLs with detailed technical hints
- Blog posts contain explicit vulnerability descriptions
